package com.example.abcprimaryschoolteachers;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.abcprimaryschoolteachers.database.DBHelper;
import com.example.abcprimaryschoolteachers.database.DBManager;
import com.example.abcprimaryschoolteachers.domain.Student;

import java.util.ArrayList;
import java.util.List;

public class StudentsEnrolled extends AppCompatActivity {

    ListView StudentEnrolledList;
    List<String> ListElementsArrayList = new ArrayList<>();
    final List<Student> ListStudentsElementsArrayList = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_student);
        getSupportActionBar().setTitle("Students");


        setDataListView();
        StudentEnrolledList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Student m = ListStudentsElementsArrayList.get(position);
                Intent i = new Intent(getApplicationContext(), EditStudentDetails.class);
                i.putExtra("student_id", String.valueOf(m.getId()));
                startActivityForResult(i,2);
            }
        });

        StudentEnrolledList.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                final Student m  = ListStudentsElementsArrayList.get(position);
                androidx.appcompat.app.AlertDialog.Builder alert = new androidx.appcompat.app.AlertDialog.Builder(getApplicationContext());
                alert.setTitle("Alert");
                alert.setMessage("Are you sure that you want to delete this item?");
                alert.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        DBManager db = new DBManager(getApplicationContext());
                        db.delete(DBHelper.TABLE_STUDENT,DBHelper.KEY_STUDENT_ID+"=?",new String[]{""+m.getId()});
                        setDataListView();
                        dialog.dismiss();
                    }
                });
                alert.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                alert.show();
                return true;
            }
        });
    }

    private void setDataListView() {
        ListElementsArrayList.clear();
        ListStudentsElementsArrayList.clear();
        DBManager db = new DBManager(getApplicationContext());
        String[] columns = new String[]{DBHelper.KEY_STUDENT_ID, DBHelper.KEY_STUDENT_NAME, DBHelper.KEY_STUDENT_EMAIL, DBHelper.KEY_STUDENT_PHONE};
        Cursor c = db.fetch(DBHelper.TABLE_STUDENT, columns,null,null,DBHelper.KEY_STUDENT_NAME);
        if (c != null && c.getCount() > 0) {
            do {
                Student m = new Student();
                m.setId(c.getInt((c.getColumnIndex(DBHelper.KEY_STUDENT_ID))));
                m.setName((c.getString(c.getColumnIndex(DBHelper.KEY_STUDENT_NAME))));
                m.setEmail((c.getString(c.getColumnIndex(DBHelper.KEY_STUDENT_EMAIL))));
                m.setPhone((c.getString(c.getColumnIndex(DBHelper.KEY_STUDENT_PHONE))));
                ListElementsArrayList.add(m.getName());
                ListStudentsElementsArrayList.add(m);
            } while (c.moveToNext());
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, ListElementsArrayList);
        StudentEnrolledList.setAdapter(adapter);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(0,0,Menu.NONE,"ADD").setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case 0:
                Intent show = new Intent(getApplicationContext(), AddStudentDetails.class);
                startActivityForResult(show,1);
                break;
        }
        return (super.onOptionsItemSelected(item));
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == 1 || requestCode == 2) {
                setDataListView();
            }
        }
    }
}