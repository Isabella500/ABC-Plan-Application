package com.example.abcprimaryschoolteachers;

import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


import com.example.abcprimaryschoolteachers.database.DBHelper;
import com.example.abcprimaryschoolteachers.database.DBManager;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class EditTermDetails extends AppCompatActivity {

    final Calendar myCalendar = Calendar.getInstance();
    public String whichDatePicker;
    Button btnCancel,btnSave;
    EditText edTitle,edStartDate,edEndDate;
    String termsId;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_term_details);

        getSupportActionBar().setTitle("EDIT TERMS");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        termsId = getIntent().getStringExtra("term_id");

        btnCancel = (Button) findViewById(R.id.btnCancel);
        btnSave = (Button) findViewById(R.id.btnSave);
        edTitle = (EditText) findViewById(R.id.edTitle);
        edStartDate = (EditText)  findViewById(R.id.edStartDate);
        edEndDate = (EditText)  findViewById(R.id.edEndDate);

        DBManager db = new DBManager(getApplication());
        String[] columns = new String[]{DBHelper.KEY_TERMS_ID, DBHelper.KEY_TERMS_TITLE, DBHelper.KEY_TERMS_START_DATE, DBHelper.KEY_TERMS_END_DATE};
        String whereCluse = DBHelper.KEY_TERMS_ID + "=?";
        Cursor c = db.fetch(DBHelper.TABLE_TERMS, columns, whereCluse, new String[]{termsId},null);
        if(c != null && c.getCount() > 0) {
            String title = c.getString(c.getColumnIndex(DBHelper.KEY_TERMS_TITLE));
            edTitle.setText(title);
            String startDate = c.getString(c.getColumnIndex(DBHelper.KEY_TERMS_START_DATE));
            String endDate = c.getString(c.getColumnIndex(DBHelper.KEY_TERMS_END_DATE));
            try{
                Date sd = new SimpleDateFormat("yyyy-MM-dd").parse(startDate);
                edStartDate.setText(new SimpleDateFormat("MM/dd/YY").format(sd));
                Date ed = new SimpleDateFormat("yyyy-MM-dd").parse(endDate);
                edEndDate.setText(new SimpleDateFormat("MM/dd/YY").format(ed));
            } catch (Exception e){
            }
        }

        final DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateLabel();
            }
        };

        edStartDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                whichDatePicker = "STARTDATE";
                new DatePickerDialog(com.example.abcprimaryschoolteachers.EditTermDetails.this, date, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });
        edEndDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                whichDatePicker = "ENDDATE";
                new DatePickerDialog(com.example.abcprimaryschoolteachers.EditTermDetails.this, date, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title = edTitle.getText().toString();
                String startDate = edStartDate.getText().toString();
                String endDate = edEndDate.getText().toString();
                if(title.isEmpty()){
                    Toast.makeText(getApplicationContext(),"Enter title",Toast.LENGTH_LONG).show();
                } else if(startDate.isEmpty()){
                    Toast.makeText(getApplicationContext(),"Enter start date",Toast.LENGTH_LONG).show();
                } else if(endDate.isEmpty()){
                    Toast.makeText(getApplicationContext(),"Enter end date",Toast.LENGTH_LONG).show();
                } else {
                    try {
                        Date dStartDate = new SimpleDateFormat("MM/dd/yy").parse(startDate);
                        String formatStartDate = new SimpleDateFormat("yyyy-MM-dd").format(dStartDate);

                        Date dEndDate = new SimpleDateFormat("MM/dd/yy").parse(endDate);
                        String formatEndDate = new SimpleDateFormat("yyyy-MM-dd").format(dEndDate);
                        if(dStartDate.after(dEndDate)){
                            Toast.makeText(getApplicationContext(),"end date should be greater than start date",Toast.LENGTH_LONG).show();
                            return;
                        }
                        DBManager db = new DBManager(getApplicationContext());
                        ContentValues contentValues = new ContentValues();
                        contentValues.put(DBHelper.KEY_TERMS_TITLE, title);
                        contentValues.put(DBHelper.KEY_TERMS_START_DATE, formatStartDate);
                        contentValues.put(DBHelper.KEY_TERMS_END_DATE, formatEndDate);
                        String whereCluse = DBHelper.KEY_COURSE_ID+"=?";
                        db.update(DBHelper.TABLE_TERMS,contentValues,whereCluse,new String[]{termsId});
                        Intent i = new Intent(getApplicationContext(), ListTerms.class);
                        setResult(RESULT_OK,i);
                        finish();
                    }
                    catch (Exception e){
                        Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();
                    }
                }
            }
        });
    }
    private void updateLabel() {
        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        if(whichDatePicker.equals("STARTDATE")) {
            edStartDate.setText(sdf.format(myCalendar.getTime()));
        } else if(whichDatePicker.equals("ENDDATE")) {
            edEndDate.setText(sdf.format(myCalendar.getTime()));
        }
    }
    @Override
    public boolean onSupportNavigateUp(){
        finish();
        return true;
    }
}