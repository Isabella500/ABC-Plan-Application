                        package com.example.abcprimaryschoolteachers;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.abcprimaryschoolteachers.database.DBHelper;
import com.example.abcprimaryschoolteachers.database.DBManager;

public class EditStudentDetails extends AppCompatActivity {

    Button btnCancel,btnSave;
    EditText edName,edEmail,edPhone;
    String studentId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_student_details);

        getSupportActionBar().setTitle("View/Edit Student");

        btnCancel = findViewById(R.id.btnCancel);
        btnSave = findViewById(R.id.btnSave);
        edName = findViewById(R.id.edNameValue);
        edEmail = findViewById(R.id.edEmailValue);
        edPhone = findViewById(R.id.edphnoValue);

        studentId = getIntent().getStringExtra("student_id");
        setDataForEdit();
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = edName.getText().toString();
                String email = edEmail.getText().toString();
                String phone = edPhone.getText().toString();
                StringBuffer sb = new StringBuffer();
                if(name.trim().equals("")) sb.append("Enter Name");
                else if(email.trim().equals("")) sb.append("Enter Email");
                else if(phone.trim().equals("")) sb.append("Enter Phone");
                if(sb.toString().equals("")){
                    DBManager db = new DBManager(getApplication());
                    ContentValues contentValues = new ContentValues();
                    contentValues.put(DBHelper.KEY_STUDENT_NAME, name);
                    contentValues.put(DBHelper.KEY_STUDENT_EMAIL,email);
                    contentValues.put(DBHelper.KEY_STUDENT_PHONE, phone);
                    String whereCluse = DBHelper.KEY_STUDENT_ID+"=?";
                    db.update(DBHelper.TABLE_STUDENT,contentValues,whereCluse,new String[]{studentId});
                    Intent i = new Intent();
                    setResult(Activity.RESULT_OK,i);
                    finish();
                } else{
                    Toast.makeText(getApplicationContext(),sb.toString(),Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private void setDataForEdit() {
        DBManager db = new DBManager(getApplication());
        String[] columns = new String[]{DBHelper.KEY_STUDENT_ID, DBHelper.KEY_STUDENT_NAME, DBHelper.KEY_STUDENT_EMAIL, DBHelper.KEY_STUDENT_PHONE};
        String whereCluse = DBHelper.KEY_STUDENT_ID + "=?";
        Cursor c = db.fetch(DBHelper.TABLE_STUDENT, columns, whereCluse, new String[]{studentId},null);
        if(c != null && c.getCount() > 0) {
            edName.setText(c.getString(c.getColumnIndex(DBHelper.KEY_STUDENT_NAME)));
            edEmail.setText(c.getString(c.getColumnIndex(DBHelper.KEY_STUDENT_EMAIL)));
            edPhone.setText(c.getString(c.getColumnIndex(DBHelper.KEY_STUDENT_PHONE)));
        }
    }


}