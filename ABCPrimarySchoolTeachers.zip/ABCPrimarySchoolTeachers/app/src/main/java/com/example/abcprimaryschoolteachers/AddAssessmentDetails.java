package com.example.abcprimaryschoolteachers;

import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.abcprimaryschoolteachers.database.DBHelper;
import com.example.abcprimaryschoolteachers.database.DBManager;
import com.example.abcprimaryschoolteachers.notification.NotificationSchedulerManager;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class AddAssessmentDetails extends AppCompatActivity {

    Button btnCancel,btnSave;

    final Calendar myCalendar = Calendar.getInstance();
    EditText dueDate;

    String courseId,termId,courseName;

    Spinner typeSpinner;
    final List<String> typeList = Arrays.asList("MidTerm Exam","Final Exam");

    CheckBox chkboxAlert;
    EditText edName;

    TextView lbl_course_name;
    @Override
    protected void onCreate(Bundle savedInstanc2eState) {
        super.onCreate(savedInstanc2eState);
        setContentView(R.layout.activity_add_assessment_details);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Add Assessment");

        courseId = getIntent().getStringExtra("course_id");
        termId = getIntent().getStringExtra("term_id");
        courseName =getIntent().getStringExtra("course_name");

        lbl_course_name= findViewById(R.id.lbl_course_name);
        btnCancel = findViewById(R.id.btnCancel);
        btnSave = findViewById(R.id.btnSave);
        edName = findViewById(R.id.edName);
        dueDate = findViewById(R.id.edDueDate);
        chkboxAlert = findViewById(R.id.chkboxAlert);

        lbl_course_name.setText("COURSE : "+courseName);

        ///////// type spinner ///////////////
        typeSpinner = (Spinner) findViewById(R.id.select_type);
        typeSpinner.setPrompt("Select Type");
        ArrayAdapter<String> typeAdapter = new ArrayAdapter<String>(getApplicationContext(),
                android.R.layout.simple_list_item_1,typeList);
        typeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        typeSpinner.setAdapter(typeAdapter);

        final DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateLabel();
            }
        };
        dueDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DatePickerDialog(com.example.abcprimaryschoolteachers.AddAssessmentDetails.this, date, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = edName.getText().toString();
                String sdueDate = dueDate.getText().toString();
                if(name.isEmpty()){
                    Toast.makeText(getApplicationContext(),"Enter Name",Toast.LENGTH_LONG).show();
                } else if(sdueDate.isEmpty()){
                    Toast.makeText(getApplicationContext(),"Select due date",Toast.LENGTH_LONG).show();
                } else {
                    try{
                        boolean isAlert = chkboxAlert.isChecked();
                        int alertCode = 0;
                        if(isAlert){
                            try{
                                long lDueDate = NotificationSchedulerManager.convertToTimestamp(sdueDate);
                                if(lDueDate >= NotificationSchedulerManager.getCurrentDateInLong()){
                                    String msg = "Your "+name+" of "+courseName+" is due today.";

                                    lDueDate += 60000;

                                    alertCode = NotificationSchedulerManager.setNotification(getApplicationContext(),"Assignment",msg,lDueDate,0);
                                    Toast.makeText(getApplicationContext(),"Scheduler set At "+sdueDate,Toast.LENGTH_LONG).show();
                                }
                            }catch (Exception e){
                                System.out.println(e.getMessage());
                            }
                        }
                        Date endDate = new SimpleDateFormat("MM/dd/yy").parse(sdueDate);
                        String formatEndDate = new SimpleDateFormat("yyyy-MM-dd").format(endDate);
                        DBManager db = new DBManager(getApplicationContext());
                        ContentValues contentValues = new ContentValues();

                        contentValues.put(DBHelper.KEY_ASSESSMENT_COURSE_ID, courseId);
                        contentValues.put(DBHelper.KEY_ASSESSMENT_DUEDATE, formatEndDate);
                        contentValues.put(DBHelper.KEY_ASSESSMENT_NAME, name);
                        contentValues.put(DBHelper.KEY_ASSESSMENT_DUE_ALERT_CODE,alertCode);
                        contentValues.put(DBHelper.KEY_ASSESSMENT_TYPE, typeSpinner.getSelectedItem().toString());
                        long id = db.insert(DBHelper.TABLE_ASSESSMENT, contentValues);

                        Intent i = new Intent();
                        setResult(RESULT_OK, i);
                        finish();
                    }catch (Exception e){
                    }

                }
            }
        });
    }


    private void updateLabel() {
        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat);
        dueDate.setText(sdf.format(myCalendar.getTime()));
    }

    @Override
    public boolean onSupportNavigateUp(){
        finish();
        return true;
    }
}