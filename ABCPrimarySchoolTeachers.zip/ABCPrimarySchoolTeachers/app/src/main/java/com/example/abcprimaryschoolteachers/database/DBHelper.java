package com.example.abcprimaryschoolteachers.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.example.abcprimaryschoolteachers.domain.Student;

import java.util.List;

public class DBHelper extends SQLiteOpenHelper {

    // Database Version
    private static final int DATABASE_VERSION = 1;
    // Database Name
    private static final String DATABASE_NAME = "wguPlanner";

    //Table Terms
    public static final String TABLE_TERMS = "terms";
    public static final String KEY_TERMS_ID = "id";
    public static final String KEY_TERMS_TITLE = "title";
    public static final String KEY_TERMS_START_DATE = "start_date";
    public static final String KEY_TERMS_END_DATE = "end_date";
    private static final String CREATE_TABLE_TERMS = "CREATE TABLE "+ TABLE_TERMS + "("
            + KEY_TERMS_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + KEY_TERMS_TITLE + " TEXT,"
            + KEY_TERMS_START_DATE + " DATE,"
            + KEY_TERMS_END_DATE + " DATE" + ")";

    //Table Course
    public static final String TABLE_COURSE = "courses";
    public static final String KEY_COURSE_ID = "id";
    public static final String KEY_COURSE_TERMS_ID = "terms_id";
    public static final String KEY_COURSE_STUDENT_ID = "mentor_id";
    public static final String KEY_COURSE_TITLE = "title";
    public static final String KEY_COURSE_START_DATE = "start_date";
    public static final String KEY_COURSE_START_ALERT_CODE = "start_alert_code";
    public static final String KEY_COURSE_END_ALERT_CODE = "end_alert_code";
    public static final String KEY_COURSE_END_DATE = "end_date";
    public static final String KEY_COURSE_WHERE= "status";
    public static final String CREATE_TABLE_COURSE ="CREATE TABLE " + TABLE_COURSE + "("
            + KEY_COURSE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + KEY_COURSE_TERMS_ID + " INTEGER,"
            + KEY_COURSE_STUDENT_ID + " INTEGER,"
            + KEY_COURSE_TITLE + " TEXT,"
            + KEY_COURSE_START_DATE + " DATE,"
            + KEY_COURSE_START_ALERT_CODE+ " TEXT,"
            + KEY_COURSE_END_DATE + " DATE,"
            + KEY_COURSE_END_ALERT_CODE+ " TEXT,"
            + KEY_COURSE_WHERE+ " TEXT" + ")";

    // Table Students
    public static final String TABLE_STUDENT = "students";
    public static final String KEY_STUDENT_ID = "id";
    public static final String KEY_STUDENT_NAME = "name";
    public static final String KEY_STUDENT_EMAIL = "email";
    public static final String KEY_STUDENT_PHONE = "phone";
    private static final String CREATE_TABLE_STUDENT = "CREATE TABLE "+ TABLE_STUDENT + "("
            + KEY_STUDENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + KEY_STUDENT_NAME + " TEXT,"
            + KEY_STUDENT_EMAIL + " TEXT,"
            + KEY_STUDENT_PHONE + " TEXT" + ")";

    //Table Assessment
    public static final String TABLE_ASSESSMENT = "assessment";
    public static final String KEY_ASSESSMENT_ID = "id";
    public static final String KEY_ASSESSMENT_COURSE_ID = "course_id";
    public static final String KEY_ASSESSMENT_NAME = "name";
    public static final String KEY_ASSESSMENT_DUEDATE = "due_date";
    public static final String KEY_ASSESSMENT_DUE_ALERT_CODE = "alert_code";
    public static final String KEY_ASSESSMENT_TYPE = "type";
    private static final String CREATE_TABLE_ASSESSMENT = "CREATE TABLE "+ TABLE_ASSESSMENT + "("
            + KEY_ASSESSMENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + KEY_ASSESSMENT_COURSE_ID + " INTEGER,"
            + KEY_ASSESSMENT_NAME + " TEXT,"
            + KEY_ASSESSMENT_DUEDATE + " DATE,"
            + KEY_ASSESSMENT_DUE_ALERT_CODE + " TEXT,"
            + KEY_ASSESSMENT_TYPE + " TEXT" + ")";


    //Table Course note
    public static final String TABLE_COURSE_NOTES = "course_notes";
    public static final String KEY_CNOTES_ID = "id";
    public static final String KEY_CNOTES_COURSE_ID = "course_id";
    public static final String KEY_CNOTES_TITLE = "title";
    public static final String KEY_CNOTES_NOTE = "notes";
    public static final String CREATE_TABLE_COURSE_NOTES ="CREATE TABLE " + TABLE_COURSE_NOTES + "("
            + KEY_CNOTES_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + KEY_CNOTES_COURSE_ID + " INTEGER,"
            + KEY_CNOTES_TITLE + " TEXT,"
            + KEY_CNOTES_NOTE+ " TEXT" + ")";

    //Table alert_notification note
    public static final String TABLE_ALERT = "alert_notification";
    public static final String KEY_ALERT_CODE = "alert_code";
    public static final String KEY_ALERT_ALERT_TYPE = "alert_type"; //COURSE or ASSIGNMENT
    public static final String KEY_ALERT_EVENT_AT = "event_at"; //time in long
    public static final String KEY_ALERT_EVENT_WHERE = "event_status"; // alert status pending or executed
    public static final String CREATE_TABLE_ALERT ="CREATE TABLE " + TABLE_ALERT + "("
            + KEY_ALERT_CODE + " TEXT,"
            + KEY_ALERT_ALERT_TYPE + " TEXT,"
            + KEY_ALERT_EVENT_WHERE + " TEXT,"
            + KEY_ALERT_EVENT_AT+ " DATE)";


    public DBHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_TERMS);
        db.execSQL(CREATE_TABLE_COURSE);
        db.execSQL(CREATE_TABLE_STUDENT);
        db.execSQL(CREATE_TABLE_ASSESSMENT);
        db.execSQL(CREATE_TABLE_COURSE_NOTES);
        db.execSQL(CREATE_TABLE_ALERT);
        System.out.println("====================ALL TABLE CREATED =================");
        inserStudents(db);
    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_TERMS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_COURSE);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_STUDENT);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ASSESSMENT);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_COURSE_NOTES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ALERT);

        onCreate(db);
    }
    private void inserStudents(SQLiteDatabase db) {
        System.out.println("-----------------Insert Mentors---------------");
        List<Student> ListMentorsElementsArrayList = Student.getStaticStudent();
        for (int i =0; i<ListMentorsElementsArrayList.size(); i++){
            ContentValues contentValues = new ContentValues();
            contentValues.put(DBHelper.KEY_STUDENT_NAME, ListMentorsElementsArrayList.get(i).getName());
            contentValues.put(DBHelper.KEY_STUDENT_EMAIL,ListMentorsElementsArrayList.get(i).getEmail());
            contentValues.put(DBHelper.KEY_STUDENT_PHONE, "1234567890");
            db.insert(DBHelper.TABLE_STUDENT,null,contentValues);
        }
    }
}
