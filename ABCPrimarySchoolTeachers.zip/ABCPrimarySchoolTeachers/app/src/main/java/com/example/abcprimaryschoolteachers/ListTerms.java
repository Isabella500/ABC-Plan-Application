package com.example.abcprimaryschoolteachers;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.abcprimaryschoolteachers.database.DBHelper;
import com.example.abcprimaryschoolteachers.database.DBManager;

import java.util.ArrayList;
import java.util.List;

public class ListTerms extends AppCompatActivity {

    ListView listViewAllTerms;
    List<String> listData = new ArrayList<>();
    final List<String> listIDData = new ArrayList<>();
    private int ADD_TERM_DETAIL_CODE = 1;
    private int TERM_DETAIL_VIEW_CODE  = 2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_terms);
        getSupportActionBar().setTitle("Terms");

        listViewAllTerms = (ListView) findViewById(R.id.listViewAllTerms);
        loadData();
        listViewAllTerms.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            String TermId = listIDData.get(position);
            Intent i = new Intent(getApplicationContext(), TermDetailedView.class);
            i.putExtra("term_id", TermId);
            startActivityForResult(i,TERM_DETAIL_VIEW_CODE);
            }
        });

        listViewAllTerms.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            String termId;
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                termId = listIDData.get(position);
                AlertDialog.Builder alert = new AlertDialog.Builder(com.example.abcprimaryschoolteachers.ListTerms.this);
                alert.setTitle("Alert");
                alert.setMessage("Are you sure to delete?");
                alert.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        int countCourse = countNoOfCoursesForThisTerm(termId);
                        if(countCourse != 0){
                            Toast.makeText(getApplicationContext(),"You can't delete terms because course is assigned",Toast.LENGTH_LONG).show();
                        } else {
                            DBManager db = new DBManager(getApplicationContext());
                            db.delete(DBHelper.TABLE_TERMS,DBHelper.KEY_TERMS_ID+"=?",new String[]{termId});
                            loadData();
                        }
                        dialog.dismiss();
                    }
                });
                alert.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                alert.show();
                return true;
            }
        });
    }

    private void loadData() {
        listData.clear();
        listIDData.clear();
        DBManager db = new DBManager(getApplicationContext());
        String[] columns = new String[]{DBHelper.KEY_TERMS_ID, DBHelper.KEY_TERMS_TITLE, DBHelper.KEY_TERMS_START_DATE, DBHelper.KEY_TERMS_END_DATE};
        Cursor c = db.fetch(DBHelper.TABLE_TERMS, columns,null,null,DBHelper.KEY_TERMS_TITLE);
        if (c != null && c.getCount() > 0) {
            do {
                String data = c.getString(c.getColumnIndex(DBHelper.KEY_TERMS_TITLE))+" \n"
                        + c.getString(c.getColumnIndex(DBHelper.KEY_TERMS_START_DATE))
                        +" - "
                        + c.getString(c.getColumnIndex(DBHelper.KEY_TERMS_END_DATE));
                listIDData.add(c.getString(c.getColumnIndex(DBHelper.KEY_TERMS_ID)));
                listData.add(data);
            } while (c.moveToNext());
        }else{
            Toast.makeText(getApplicationContext(),"No Data Found",Toast.LENGTH_LONG).show();
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listData);
        listViewAllTerms.setAdapter(adapter);
    }

    private int countNoOfCoursesForThisTerm(String termsId) {
        int cnt = 0;
        DBManager db = new DBManager(getApplication());
        String qry = "select"
                +" count("+DBHelper.KEY_COURSE_TERMS_ID+")"
                + " from "
                + DBHelper.TABLE_COURSE
                +" where "+DBHelper.KEY_COURSE_TERMS_ID+"="+termsId;
        Cursor c = db.fetchWithQuery(qry);
        if(c != null && c.getCount() > 0) {
            cnt =c.getInt(0);
        }
        return  cnt;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(0,Menu.FIRST,Menu.NONE,"ADD").setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case 1:
                Intent show = new Intent(getApplicationContext(), AddTermsDetails.class);
                startActivityForResult(show,ADD_TERM_DETAIL_CODE);
                break;
        }
        return (super.onOptionsItemSelected(item));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == ADD_TERM_DETAIL_CODE || requestCode == TERM_DETAIL_VIEW_CODE) {
                loadData();
            }
        }
    }
}