package com.example.abcprimaryschoolteachers;

import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.abcprimaryschoolteachers.database.DBHelper;
import com.example.abcprimaryschoolteachers.database.DBManager;
import com.example.abcprimaryschoolteachers.domain.Student;
import com.example.abcprimaryschoolteachers.notification.NotificationSchedulerManager;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class EditCourseDetails extends AppCompatActivity {

    String courseId,termsId;
    Spinner whereSpinner;
    public EditText edCourseTitle,courseStart,courseEnd;
    final Calendar myCalendar = Calendar.getInstance();
    public String whichDatePicker;
    Button btnCancel,btnSave;
    ArrayAdapter<String> whereAdapter;

    Spinner  studentSpinner;
    String studentId;
    List<String> studentList = new ArrayList<>();
    final List<Student> ListStudentElementsArrayList = new ArrayList<>();

    TextView lblTermName;
    CheckBox chkboxStartDateAlert,chkboxEndDateAlert;
    int oldStartAlertCode = 0,oldEndAlertCode = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_course_details);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Edit Course");

        btnCancel = (Button) findViewById(R.id.btnCancel);
        btnSave = (Button) findViewById(R.id.btnSave);
        edCourseTitle = (EditText) findViewById(R.id.edCourseTitle);
        courseStart = (EditText) findViewById(R.id.editCourseStart);
        courseEnd = (EditText) findViewById(R.id.edCourseEnd);
        chkboxStartDateAlert = findViewById(R.id.chkboxStartDateAlert);
        lblTermName = (TextView) findViewById(R.id.lblTermName);
        chkboxEndDateAlert = findViewById(R.id.chkboxEndDateAlert);

        courseId = getIntent().getStringExtra("course_id");

        whereSpinner= (Spinner) findViewById(R.id.select_where);
        List<String> whereList = new ArrayList<>();
        whereSpinner.setPrompt("WHERE");
        whereList.add("Course # 2001");
        whereList.add("Course # 2002");
        whereList.add("Course # 2003");
        whereList.add("Course # 2003");
        whereList.add("Course # 2004");
        whereList.add("Course # 2004");
        whereList.add("Course # 2005");
        whereList.add("Course # 2006");
        whereList.add("Course # 2006");
        whereList.add("Course # 2007");

        whereAdapter = new ArrayAdapter<String>(getApplicationContext(),
                android.R.layout.simple_list_item_1,whereList);
        whereAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        whereSpinner.setAdapter(whereAdapter);

        setDataForEdit();

        ///////////// Mentor ////////
        studentSpinner = (Spinner) findViewById(R.id.select_student);
        studentSpinner.setPrompt("Select Student");
        loadStudentDataInSpinner();

        final DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateLabel();
            }
        };

        courseStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                whichDatePicker = "STARTDATE";
                new DatePickerDialog(com.example.abcprimaryschoolteachers.EditCourseDetails.this, date, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });
        courseEnd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                whichDatePicker = "ENDDATE";
                new DatePickerDialog(com.example.abcprimaryschoolteachers.EditCourseDetails.this, date, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String courseTitle = edCourseTitle.getText().toString();
                String editCourseStart = courseStart.getText().toString();
                String edCourseEnd = courseEnd.getText().toString();
                if(courseTitle.isEmpty()){
                    Toast.makeText(getApplicationContext(),"Enter title",Toast.LENGTH_LONG).show();
                } else if(editCourseStart.isEmpty()){
                    Toast.makeText(getApplicationContext(),"Enter start date",Toast.LENGTH_LONG).show();
                } else if(edCourseEnd.isEmpty()){
                    Toast.makeText(getApplicationContext(),"Enter end date",Toast.LENGTH_LONG).show();
                } else {
                    try {
                        Date StartDate = new SimpleDateFormat("MM/dd/yy").parse(editCourseStart);
                        String formatStartDate = new SimpleDateFormat("yyyy-MM-dd").format(StartDate);

                        Date endDate = new SimpleDateFormat("MM/dd/yy").parse(edCourseEnd);
                        String formatEndDate = new SimpleDateFormat("yyyy-MM-dd").format(endDate);

                        if(StartDate.after(endDate)){
                            Toast.makeText(getApplicationContext(),"end date should be greater than start date",Toast.LENGTH_LONG).show();
                            return;
                        }

                        String toastMsg ="";
                        int startAlertCode = 0,endAlertCode = 0;
                        if(chkboxStartDateAlert.isChecked()){
                            long lstartDate = NotificationSchedulerManager.convertToTimestamp(editCourseStart);
                            if(lstartDate >= NotificationSchedulerManager.getCurrentDateInLong()){
                                String msg = "Your "+courseTitle+" Starts today.";
                                startAlertCode = NotificationSchedulerManager.setNotification(getApplicationContext(),"Course",msg,lstartDate,oldStartAlertCode);
                                toastMsg = "Course start date scheduler set At "+editCourseStart;
                            }
                        }else if(oldStartAlertCode != 0){
                            NotificationSchedulerManager.deleteAlarm(getApplicationContext(),oldStartAlertCode);
                        }
                        if(chkboxEndDateAlert.isChecked()){
                            long lendDate = NotificationSchedulerManager.convertToTimestamp(edCourseEnd);
                            if(lendDate >= NotificationSchedulerManager.getCurrentDateInLong()){
                                String msg = "Your "+courseTitle+" ends today.";
                                endAlertCode = NotificationSchedulerManager.setNotification(getApplicationContext(),"Course",msg,lendDate,oldEndAlertCode);
                                toastMsg += "\nCourse end date scheduler set At "+edCourseEnd;
                            }
                        }else if(oldEndAlertCode != 0){
                            NotificationSchedulerManager.deleteAlarm(getApplicationContext(),oldEndAlertCode);
                        }
                        if(!toastMsg.equals("")){
                            Toast.makeText(getApplicationContext(),toastMsg,Toast.LENGTH_LONG).show();
                        }
                        DBManager db = new DBManager(getApplicationContext());
                        ContentValues contentValues = new ContentValues();
                        contentValues.put(DBHelper.KEY_COURSE_TERMS_ID, termsId);
                        contentValues.put(DBHelper.KEY_COURSE_TITLE, courseTitle);
                        contentValues.put(DBHelper.KEY_COURSE_START_DATE, formatStartDate);
                        contentValues.put(DBHelper.KEY_COURSE_END_DATE, formatEndDate);
                        contentValues.put(DBHelper.KEY_COURSE_START_ALERT_CODE,startAlertCode);
                        contentValues.put(DBHelper.KEY_COURSE_END_ALERT_CODE,endAlertCode);
                        contentValues.put(DBHelper.KEY_COURSE_WHERE, whereSpinner.getSelectedItem().toString());
                        String whereCluse = DBHelper.KEY_COURSE_ID + "=?";
                        db.update(DBHelper.TABLE_COURSE, contentValues, whereCluse, new String[]{courseId});
                        //String msg = " title : "+courseTitle+" sdate :"+formatStartDate+" edate : "+formatEndDate;
                        // Toast.makeText(getApplicationContext(),msg,Toast.LENGTH_LONG).show();
                        Intent i = new Intent();
                        setResult(RESULT_OK, i);
                        finish();
                    } catch (Exception e) {
                    }
                }
            }
        });
    }

    private void loadStudentDataInSpinner() {
        studentList.clear();
        ListStudentElementsArrayList.clear();
        DBManager db = new DBManager(getApplicationContext());
        String[] columns = new String[]{DBHelper.KEY_STUDENT_ID, DBHelper.KEY_STUDENT_NAME,DBHelper.KEY_STUDENT_EMAIL,DBHelper.KEY_STUDENT_PHONE};
        Cursor c  = db.fetch(DBHelper.TABLE_STUDENT,columns,null,null, DBHelper.KEY_STUDENT_NAME);
        int pos=0;
        boolean isfirst = true;
        if (c != null && c.getCount() > 0) {
            do {
                Student m = new Student();
                m.setId(c.getInt((c.getColumnIndex(DBHelper.KEY_STUDENT_ID))));
                m.setName(c.getString(c.getColumnIndex(DBHelper.KEY_STUDENT_NAME)));
                m.setEmail(c.getString(c.getColumnIndex(DBHelper.KEY_STUDENT_EMAIL)));
                m.setPhone(c.getString(c.getColumnIndex(DBHelper.KEY_STUDENT_PHONE)));
                studentList.add(m.getName());
                ListStudentElementsArrayList.add(m);
                if(isfirst || studentId.equals(""+m.getId())){
                    pos = ListStudentElementsArrayList.size() -1;
                    isfirst = false;
                }
            } while (c.moveToNext());
        }
        ArrayAdapter<String> studentAdapter = new ArrayAdapter<String>(getApplicationContext(),
                android.R.layout.simple_list_item_1,studentList);
        studentAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        studentSpinner.setAdapter(studentAdapter);
        studentSpinner.setSelection(pos);
    }

    private void setDataForEdit() {
        DBManager db = new DBManager(getApplicationContext());
        String[] columns = new String[]{DBHelper.KEY_COURSE_ID, DBHelper.KEY_COURSE_TITLE, DBHelper.KEY_COURSE_START_DATE,
                DBHelper.KEY_COURSE_END_DATE, DBHelper.KEY_COURSE_WHERE, DBHelper.KEY_COURSE_TERMS_ID, DBHelper.KEY_COURSE_STUDENT_ID,
                DBHelper.KEY_COURSE_START_ALERT_CODE,DBHelper.KEY_COURSE_END_ALERT_CODE};
        String whereCluse = DBHelper.KEY_COURSE_ID + "=?";
        Cursor c = db.fetch(DBHelper.TABLE_COURSE, columns, whereCluse, new String[]{courseId}, null);
        if (c != null && c.getCount() > 0) {
            edCourseTitle.setText(c.getString(c.getColumnIndex(DBHelper.KEY_COURSE_TITLE)));
            termsId = c.getString(c.getColumnIndex(DBHelper.KEY_COURSE_TERMS_ID));
            studentId = c.getString(c.getColumnIndex(DBHelper.KEY_COURSE_STUDENT_ID));
            //Toast.makeText(getApplicationContext(),mentorId,Toast.LENGTH_LONG).show();
            String selectedWhere = c.getString(c.getColumnIndex(DBHelper.KEY_COURSE_WHERE));
            int position = whereAdapter.getPosition(selectedWhere);
            whereSpinner.setSelection(position);
            String startDate = c.getString(c.getColumnIndex(DBHelper.KEY_COURSE_START_DATE));
            String endDate = c.getString(c.getColumnIndex(DBHelper.KEY_COURSE_END_DATE));
            try {
                Date sd = new SimpleDateFormat("yyyy-MM-dd").parse(startDate);
                courseStart.setText(new SimpleDateFormat("MM/dd/YYYY").format(sd));
                Date ed = new SimpleDateFormat("yyyy-MM-dd").parse(endDate);
                courseEnd.setText(new SimpleDateFormat("MM/dd/YYYY").format(ed));
            } catch (Exception e) {
            }
            oldStartAlertCode = c.getInt(c.getColumnIndex(DBHelper.KEY_COURSE_START_ALERT_CODE));
            oldEndAlertCode = c.getInt(c.getColumnIndex(DBHelper.KEY_COURSE_END_ALERT_CODE));
            if(oldStartAlertCode != 0){
                chkboxStartDateAlert.setChecked(true);
            }
            if(oldEndAlertCode != 0){
                chkboxEndDateAlert.setChecked(true);
            }
            setTermName();
        }

    }

    private void setTermName() {
        DBManager db = new DBManager(getApplicationContext());
        String[] columns = new String[]{DBHelper.KEY_TERMS_ID, DBHelper.KEY_TERMS_TITLE};
        String whereCluse = DBHelper.KEY_TERMS_ID +"=?";
        Cursor c  = db.fetch(DBHelper.TABLE_TERMS,columns,whereCluse,new String[]{termsId}, DBHelper.KEY_TERMS_TITLE);

        if (c != null && c.getCount() > 0) {
            lblTermName.setText("TERM : "+c.getString(c.getColumnIndex(DBHelper.KEY_TERMS_TITLE)));
        }

    }

    private void updateLabel() {
        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat);
        if(whichDatePicker.equals("STARTDATE")) {
            courseStart.setText(sdf.format(myCalendar.getTime()));
        } else if(whichDatePicker.equals("ENDDATE")) {
            courseEnd.setText(sdf.format(myCalendar.getTime()));
        }
    }
    @Override
    public boolean onSupportNavigateUp(){
        finish();
        return true;
    }
}