package com.example.abcprimaryschoolteachers;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.abcprimaryschoolteachers.database.DBHelper;
import com.example.abcprimaryschoolteachers.database.DBManager;

public class EditCourseNoteDetails extends AppCompatActivity {

    Button btnCancel,btnSave;

    String courseId,courseName,termId,noteId;

    TextView txtCourseName;

    EditText edNote,edTitle;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_course_note_details);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("View/Edit Note");

        noteId = getIntent().getStringExtra("note_id");
        termId = getIntent().getStringExtra("term_id");
        courseName = getIntent().getStringExtra("course_name");

        txtCourseName = findViewById(R.id.lbl_course_name);
        edTitle = findViewById(R.id.edTitle);
        edNote = findViewById(R.id.edNote);
        btnCancel = findViewById(R.id.btnCancel);
        btnSave = findViewById(R.id.btnSave);

        txtCourseName.setText("Course : "+courseName);

        setDataForEdit();

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title = edTitle.getText().toString();
                String note = edNote.getText().toString();
                if(title.isEmpty()){
                    Toast.makeText(getApplicationContext(),"Enter Title",Toast.LENGTH_LONG).show();
                } else if(note.isEmpty()){
                    Toast.makeText(getApplicationContext(),"Enter Note",Toast.LENGTH_LONG).show();
                } else {
                    DBManager db = new DBManager(getApplicationContext());
                    ContentValues contentValues = new ContentValues();
                    contentValues.put(DBHelper.KEY_CNOTES_COURSE_ID,courseId);
                    contentValues.put(DBHelper.KEY_CNOTES_TITLE, title);
                    contentValues.put(DBHelper.KEY_CNOTES_NOTE, note);
                    String whereCluse =DBHelper.KEY_CNOTES_ID+"=?";
                    db.update(DBHelper.TABLE_COURSE_NOTES, contentValues,whereCluse,new String[]{noteId});
                    Intent i = new Intent();
                    setResult(RESULT_OK, i);
                    finish();
                }
            }
        });
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(0,0,Menu.NONE,"SHARE").setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case 0:
                String title = edTitle.getText().toString();
                String note = edNote.getText().toString();
                Intent textMessage = new Intent(Intent.ACTION_SEND);
                textMessage.putExtra(Intent.EXTRA_SUBJECT, title);
                textMessage.putExtra(Intent.EXTRA_TEXT, note);
                textMessage.setType("text/plain");
                startActivity(Intent.createChooser(textMessage, "Choose an Email client :"));
                break;
        }
        return (super.onOptionsItemSelected(item));
    }
    private void setDataForEdit() {
        DBManager db = new DBManager(getApplicationContext());
        String[] columns = new String[]{DBHelper.KEY_CNOTES_TITLE, DBHelper.KEY_CNOTES_NOTE,DBHelper.KEY_CNOTES_COURSE_ID};
        String whereCluse = DBHelper.KEY_CNOTES_ID + "=?";
        Cursor c = db.fetch(DBHelper.TABLE_COURSE_NOTES, columns, whereCluse, new String[]{noteId},null);
        if (c != null && c.getCount() > 0) {
            edTitle.setText(c.getString(c.getColumnIndex(DBHelper.KEY_CNOTES_TITLE)));
            courseId = c.getString(c.getColumnIndex(DBHelper.KEY_CNOTES_COURSE_ID));
            edNote.setText(c.getString(c.getColumnIndex(DBHelper.KEY_CNOTES_NOTE)));
        }
    }
    @Override
    public boolean onSupportNavigateUp(){
        finish();
        return true;
    }
}