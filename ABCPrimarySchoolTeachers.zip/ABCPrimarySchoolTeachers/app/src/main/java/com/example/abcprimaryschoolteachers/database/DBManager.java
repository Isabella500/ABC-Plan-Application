package com.example.abcprimaryschoolteachers.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class DBManager {
    private DBHelper dbHelper;
    private Context context;
    private SQLiteDatabase database;

    public DBManager(Context c) {
        this.context = c;
        dbHelper = new DBHelper(context);
    }

    public long insert(String tableName, ContentValues contentValues) {
        database = dbHelper.getWritableDatabase();
        long id = database.insert(tableName, null, contentValues);
        dbHelper.close();
        return  id;
    }

    public void update(String tableName, ContentValues contentValues,String whereCluse,String[] selectionArgs) {
        database = dbHelper.getWritableDatabase();
        database.update(tableName, contentValues, whereCluse, selectionArgs);
        dbHelper.close();

    }
    public void delete(String tableName, String whereCluse,String[] whereArgs) {
        database = dbHelper.getWritableDatabase();
        database.delete(tableName,whereCluse,whereArgs);
        dbHelper.close();
    }

    public Cursor fetch(String tableName, String[] columns, String selection, String[] selectionArgs, String orderBy) {
        database = dbHelper.getWritableDatabase();
        Cursor cursor = database.query(tableName, columns, selection, selectionArgs, null, null, orderBy);
        if (cursor != null) {
            cursor.moveToFirst();
            System.out.println("Cursor Records : "+cursor.getCount());
        }
        dbHelper.close();
        return cursor;
    }
    public Cursor fetchWithQuery(String query) {
        database = dbHelper.getWritableDatabase();
        Cursor cursor = database.rawQuery(query,null);
        if (cursor != null) {
            cursor.moveToFirst();
            System.out.println("Cursor Records : "+cursor.getCount());
        }
        dbHelper.close();
        return cursor;
    }

}

