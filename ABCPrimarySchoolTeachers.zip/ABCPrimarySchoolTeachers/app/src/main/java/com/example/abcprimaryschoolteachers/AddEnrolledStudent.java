package com.example.abcprimaryschoolteachers;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class AddEnrolledStudent extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_enrolled_student);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Add Student to this course");
    }
}