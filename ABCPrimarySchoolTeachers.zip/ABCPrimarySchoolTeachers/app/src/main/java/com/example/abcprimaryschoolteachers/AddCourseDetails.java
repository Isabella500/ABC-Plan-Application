package com.example.abcprimaryschoolteachers;

import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.abcprimaryschoolteachers.database.DBHelper;
import com.example.abcprimaryschoolteachers.database.DBManager;
import com.example.abcprimaryschoolteachers.domain.Student;
import com.example.abcprimaryschoolteachers.notification.NotificationSchedulerManager;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class AddCourseDetails extends AppCompatActivity {

    String termsId,termName;
    public EditText edCourseTitle,courseStart,courseEnd;
    final Calendar myCalendar = Calendar.getInstance();
    Spinner termSpinner,whereSpinner;
    public String whichDatePicker;
    Button btnCancel,btnSave;
    TextView lbl_term_name;

    CheckBox chkboxStartDateAlert,chkboxEndDateAlert;

    Spinner studentSpinner;
    List<String> studentList = new ArrayList<>();
    final List<Student> ListStudentElementsArrayList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_course_details);

        getSupportActionBar().setTitle("Add Course");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        termsId = getIntent().getStringExtra("term_id");
        termName = getIntent().getStringExtra("term_name");

        btnCancel = (Button) findViewById(R.id.btnCancel);
        btnSave = (Button) findViewById(R.id.btnSave);
        edCourseTitle = (EditText) findViewById(R.id.edCourseTitle);
        lbl_term_name = (TextView) findViewById(R.id.lbl_term_name) ;
        chkboxStartDateAlert = findViewById(R.id.chkboxStartDateAlert);
        chkboxEndDateAlert = findViewById(R.id.chkboxEndDateAlert);

        ////////// Term /////////////
        lbl_term_name.setText("TERM : "+termName);

        ///////////// Student ////////


        //////course Startdate and end date/////////////
        courseStart = (EditText) findViewById(R.id.editCourseStart);
        courseEnd = (EditText) findViewById(R.id.edCourseEnd);
        final DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateLabel();
            }
        };

        courseStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                whichDatePicker = "STARTDATE";
                new DatePickerDialog(com.example.abcprimaryschoolteachers.AddCourseDetails.this, date, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });
        courseEnd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                whichDatePicker = "ENDDATE";
                new DatePickerDialog(com.example.abcprimaryschoolteachers.AddCourseDetails.this, date, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        //////////////////////Select Where//////////////////////////////////////////////
        whereSpinner = (Spinner) findViewById(R.id.select_where);
        List<String> whereList = new ArrayList<>();
        whereSpinner.setPrompt("WHERE");
        whereList.add("COURSE # 201");
        whereList.add("COURSE # 202");
        whereList.add("COURSE # 203");
        whereList.add("COURSE # 204");
        whereList.add("COURSE # 205");
        whereList.add("COURSE # 206");
        whereList.add("COURSE # 207");
        whereList.add("COURSE # 208");
        whereList.add("COURSE # 209");
        whereList.add("COURSE # 210");

        ArrayAdapter<String> statusAdapter = new ArrayAdapter<String>(getApplicationContext(),
                android.R.layout.simple_list_item_1,whereList);
        statusAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        whereSpinner.setAdapter(statusAdapter);

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String courseTitle = edCourseTitle.getText().toString();
                String editCourseStart = courseStart.getText().toString();
                String edCourseEnd = courseEnd.getText().toString();
                if(courseTitle.isEmpty()){
                    Toast.makeText(getApplicationContext(),"Enter title",Toast.LENGTH_LONG).show();
                } else if(editCourseStart.isEmpty()){
                    Toast.makeText(getApplicationContext(),"Enter start date",Toast.LENGTH_LONG).show();
                } else if(edCourseEnd.isEmpty()){
                    Toast.makeText(getApplicationContext(),"Enter end date",Toast.LENGTH_LONG).show();
                } else {
                    try {
                        Date StartDate = new SimpleDateFormat("MM/dd/yy").parse(editCourseStart);
                        String formatStartDate = new SimpleDateFormat("yyyy-MM-dd").format(StartDate);

                        Date endDate = new SimpleDateFormat("MM/dd/yy").parse(edCourseEnd);
                        String formatEndDate = new SimpleDateFormat("yyyy-MM-dd").format(endDate);
                        if(StartDate.after(endDate)){
                            Toast.makeText(getApplicationContext(),"end date should be greater than start date",Toast.LENGTH_LONG).show();
                            return;
                        }
                        String toastMsg ="";
                        int startAlertCode = 0,endAlertCode = 0;
                        if(chkboxStartDateAlert.isChecked()){
                            long lstartDate = NotificationSchedulerManager.convertToTimestamp(editCourseStart);
                            if(lstartDate >= NotificationSchedulerManager.getCurrentDateInLong()){
                                String msg = "Your "+courseTitle+" Starts today.";
                                startAlertCode = NotificationSchedulerManager.setNotification(getApplicationContext(),"Course",msg,lstartDate,0);
                                toastMsg = "Course start date scheduler set At "+editCourseStart;
                            }
                        }
                        if(chkboxEndDateAlert.isChecked()){
                            long lendDate = NotificationSchedulerManager.convertToTimestamp(edCourseEnd);
                            if(lendDate >= NotificationSchedulerManager.getCurrentDateInLong()){
                                String msg = "Your "+courseTitle+" ends today.";
                                endAlertCode = NotificationSchedulerManager.setNotification(getApplicationContext(),"Course",msg,lendDate,0);
                                toastMsg += "\nCourse end date scheduler set At "+edCourseEnd;
                            }
                        }
                        if(!toastMsg.equals("")){
                            Toast.makeText(getApplicationContext(),toastMsg,Toast.LENGTH_LONG).show();
                        }
                        DBManager db = new DBManager(getApplicationContext());
                        ContentValues contentValues = new ContentValues();
                        contentValues.put(DBHelper.KEY_COURSE_TERMS_ID, termsId);
                        contentValues.put(DBHelper.KEY_COURSE_TITLE, courseTitle);
                        contentValues.put(DBHelper.KEY_COURSE_START_DATE, formatStartDate);
                        contentValues.put(DBHelper.KEY_COURSE_END_DATE, formatEndDate);
                        contentValues.put(DBHelper.KEY_COURSE_START_ALERT_CODE,startAlertCode);
                        contentValues.put(DBHelper.KEY_COURSE_END_ALERT_CODE,endAlertCode);
                        contentValues.put(DBHelper.KEY_COURSE_WHERE, whereSpinner.getSelectedItem().toString());
                        db.insert(DBHelper.TABLE_COURSE, contentValues);
                        Intent i = new Intent();
                        setResult(RESULT_OK, i);
                        finish();
                    } catch (Exception e) {
                        Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();
                    }
                }
            }
        });
    }





    private void updateLabel() {
        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat);
        if(whichDatePicker.equals("STARTDATE")) {
            courseStart.setText(sdf.format(myCalendar.getTime()));
        } else if(whichDatePicker.equals("ENDDATE")) {
            courseEnd.setText(sdf.format(myCalendar.getTime()));
        }
    }
    @Override
    public boolean onSupportNavigateUp(){
        finish();
        return true;
    }
}