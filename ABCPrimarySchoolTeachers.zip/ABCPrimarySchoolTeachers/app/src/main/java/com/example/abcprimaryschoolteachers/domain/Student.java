package com.example.abcprimaryschoolteachers.domain;

import java.util.ArrayList;
import java.util.List;

public class Student {
    int id;
    int courseId;
    String name;
    String email;
    String phone;

    public Student(){}
    public Student(String name) {
        this.id = id;
        this.name = name;
        this.email = name.replaceAll(" ","_")+"@gmail.com";
        this.phone = "147852615";
    }
    public Student(int id, int courseId, String name, String email, String phone) {
        this.id = id;
        this.courseId = courseId;
        this.name = name;
        this.email = email;
        this.phone = phone;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public  static List<Student> getStaticStudent(){
        List<Student> ListStudentsElementsArrayList= new ArrayList<>();
        ListStudentsElementsArrayList.add(new Student("Norman Letofsky"));
        ListStudentsElementsArrayList.add(new Student("Lukasz Gwardynski"));
        ListStudentsElementsArrayList.add(new Student("Neal Weinstein"));
        ListStudentsElementsArrayList.add(new Student("Steve Patterson"));
        ListStudentsElementsArrayList.add(new Student("William C. Mcleod"));
        ListStudentsElementsArrayList.add(new Student("Mark Williams"));
        ListStudentsElementsArrayList.add(new Student("Wendell E Engelstad"));
        ListStudentsElementsArrayList.add(new Student("Joseph M Boyd"));
        ListStudentsElementsArrayList.add(new Student("Donette Watson"));
        ListStudentsElementsArrayList.add(new Student("Darren Baer"));
        ListStudentsElementsArrayList.add(new Student("Alexander N. Shealy Jr."));
        ListStudentsElementsArrayList.add(new Student("Dean W Voeks"));
        ListStudentsElementsArrayList.add(new Student("Mark S. Zelinski"));
        ListStudentsElementsArrayList.add(new Student("Pam Conboy"));
        ListStudentsElementsArrayList.add(new Student("Alan M Haveson"));
        ListStudentsElementsArrayList.add(new Student("John Howie"));
        ListStudentsElementsArrayList.add(new Student("Thomas E Bauer"));
        ListStudentsElementsArrayList.add(new Student("Raymond Burgan"));
        ListStudentsElementsArrayList.add(new Student("Jim Levi"));
        ListStudentsElementsArrayList.add(new Student("Jerry Komejan"));
        ListStudentsElementsArrayList.add(new Student("Kirk Hawkinson"));
        return  ListStudentsElementsArrayList;
    }
}
