package com.example.abcprimaryschoolteachers;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {
    Button btnViewAllTerms,btnReport,btnViewAllStudents;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnViewAllTerms = findViewById(R.id.viewAllTerms);
        btnReport = findViewById(R.id.btn_viewReport);
        btnViewAllStudents = findViewById(R.id.btnViewAllStudents);

        btnViewAllTerms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent show = new Intent(getApplicationContext(), ListTerms.class);
                startActivity(show);
            }
        });
        btnReport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent show = new Intent(getApplicationContext(), ViewReport.class);
                startActivity(show);
            }
        });
        btnViewAllStudents.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent show = new Intent(getApplicationContext(), StudentList.class);
                startActivity(show);
            }
        });

    }
}