package com.example.abcprimaryschoolteachers;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.abcprimaryschoolteachers.database.DBHelper;
import com.example.abcprimaryschoolteachers.database.DBManager;
import com.example.abcprimaryschoolteachers.domain.Course;


import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class TermDetailedView extends AppCompatActivity {

    TextView txtTitle,txtStartDate,txtEndDate;
    String termsId,termName;
    ListView listCourses;
    List<String> ListElementsArrayList = new ArrayList<>();
    final List<Course> ListCourse = new ArrayList<>();

    private int ADD_COURSE_CODE = 1;
    private int EDIT_TERM_CODE  = 2;
    private int VIEW_COURSE_CODE  = 3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_term_detailed_view);

        getSupportActionBar().setTitle("Terms Detailed View");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        txtTitle = (TextView) findViewById(R.id.lblTitleValue);
        txtStartDate = (TextView)  findViewById(R.id.lblStartDateValue);
        txtEndDate = (TextView)  findViewById(R.id.lblEndDateValue);
        Button btnedit = findViewById(R.id.btnEditTerm);
        Button btndelete = findViewById(R.id.btnDeleteTerm);
        listCourses = findViewById(R.id.listViewCourses);

        termsId = getIntent().getStringExtra("term_id");
        setTermDetailsDataInView();

        btnedit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent show = new Intent(getApplicationContext(), EditTermDetails.class);
                show.putExtra("term_id",termsId);
                startActivityForResult(show,EDIT_TERM_CODE);
            }
        });

        btndelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int countCourse = countNoOfCoursesForThisTerm();
                if(countCourse != 0){
                    Toast.makeText(getApplicationContext(),"You can't delete terms when a course is assigned",Toast.LENGTH_LONG).show();
                } else {
                    new AlertDialog.Builder(com.example.abcprimaryschoolteachers.TermDetailedView.this)
                        .setTitle("Delete")
                        .setMessage("Are you sure you want to delete this Term?")
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                DBManager db = new DBManager(getApplicationContext());
                                db.delete(DBHelper.TABLE_TERMS, DBHelper.KEY_TERMS_ID+"=?",new String[]{termsId});
                                Intent show = new Intent(getApplicationContext(), ListTerms.class);
                                setResult(Activity.RESULT_OK,show);
                                finish();
                            }})
                        .setNegativeButton(android.R.string.no, null).show();
                }
            }
        });

        loadDataInCourseListView();
        //item click on detail view
        listCourses.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Course m = ListCourse.get(position);
                Intent i = new Intent(getApplicationContext(), CourseDetailedView.class);
                i.putExtra("course_id", String.valueOf(m.getCourseId()));
                startActivityForResult(i,VIEW_COURSE_CODE);
            }
        });
        //Long press for delete course
        listCourses.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
               final Course course = ListCourse.get(position);
                androidx.appcompat.app.AlertDialog.Builder alert = new androidx.appcompat.app.AlertDialog.Builder(com.example.abcprimaryschoolteachers.TermDetailedView.this);
                alert.setTitle("Alert");
                alert.setMessage("Are you sure you want to delete this term?");
                alert.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        DBManager db = new DBManager(getApplicationContext());
                        db.delete(DBHelper.TABLE_COURSE,DBHelper.KEY_COURSE_ID+"=?",new String[]{""+course.getCourseId()});
                        loadDataInCourseListView();
                        dialog.dismiss();
                    }
                });
                alert.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                alert.show();
                return true;
            }
        });
    }

    private void setTermDetailsDataInView() {
        DBManager db = new DBManager(getApplication());
        String[] columns = new String[]{DBHelper.KEY_TERMS_ID, DBHelper.KEY_TERMS_TITLE, DBHelper.KEY_TERMS_START_DATE, DBHelper.KEY_TERMS_END_DATE};
        String whereCluse = DBHelper.KEY_TERMS_ID + "=?";
        Cursor c = db.fetch(DBHelper.TABLE_TERMS, columns, whereCluse, new String[]{termsId},null);
        if(c != null && c.getCount() > 0) {
            termName = c.getString(c.getColumnIndex(DBHelper.KEY_TERMS_TITLE));
            txtTitle.setText(termName);
            String startDate = c.getString(c.getColumnIndex(DBHelper.KEY_TERMS_START_DATE));
            String endDate = c.getString(c.getColumnIndex(DBHelper.KEY_TERMS_END_DATE));
            try{
                Date sd = new SimpleDateFormat("yyyy-MM-dd").parse(startDate);
                txtStartDate.setText("START DATE : "+new SimpleDateFormat("MM/dd/YYYY").format(sd));
                Date ed = new SimpleDateFormat("yyyy-MM-dd").parse(endDate);
                txtEndDate.setText("END DATE : "+new SimpleDateFormat("MM/dd/YYYY").format(ed));
            } catch (Exception e){
            }
        }
    }

    private void loadDataInCourseListView() {
        ListElementsArrayList.clear();
        ListCourse.clear();
        DBManager db = new DBManager(getApplicationContext());
        String[] columns = new String[]{DBHelper.KEY_COURSE_ID, DBHelper.KEY_COURSE_TITLE, DBHelper.KEY_COURSE_START_DATE, DBHelper.KEY_COURSE_END_DATE};
        String whereCluse = DBHelper.KEY_COURSE_TERMS_ID + "=?";
        Cursor c  = db.fetch(DBHelper.TABLE_COURSE,columns,whereCluse,new String[]{termsId}, DBHelper.KEY_COURSE_TITLE);
        if (c != null && c.getCount() > 0) {
            do {
                Course m = new Course();
                m.setCourseId(c.getInt((c.getColumnIndex(DBHelper.KEY_COURSE_ID))));
                m.setCourseTitle((c.getString(c.getColumnIndex(DBHelper.KEY_COURSE_TITLE))));
                m.setCourseStartDate((c.getString(c.getColumnIndex(DBHelper.KEY_COURSE_START_DATE))));
                m.setCourseEndDate(c.getString(c.getColumnIndex(DBHelper.KEY_COURSE_END_DATE)));
                ListElementsArrayList.add(m.getCourseTitle());
                ListCourse.add(m);
            } while (c.moveToNext());
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, ListElementsArrayList);
        listCourses.setAdapter(adapter);
    }

    private int countNoOfCoursesForThisTerm() {
        int cnt = 0;
        DBManager db = new DBManager(getApplication());
        String qry = "select"
                +" count("+ DBHelper.KEY_COURSE_TERMS_ID+")"
                + " from "
                + DBHelper.TABLE_COURSE
                +" where "+DBHelper.KEY_COURSE_TERMS_ID+"="+termsId;
        Cursor c = db.fetchWithQuery(qry);
        if(c != null && c.getCount() > 0) {
            cnt =c.getInt(0);
        }
        return  cnt;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(0,Menu.FIRST,Menu.NONE,"ADD COURSE").setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case 1:
                Intent show = new Intent(getApplicationContext(), AddCourseDetails.class);
                show.putExtra("term_id",termsId);
                show.putExtra("term_name",termName);
                startActivityForResult(show,ADD_COURSE_CODE);
                break;
        }
        return (super.onOptionsItemSelected(item));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if(requestCode == EDIT_TERM_CODE) {//Edit Term
                setTermDetailsDataInView();
            } else if(requestCode == ADD_COURSE_CODE || requestCode == VIEW_COURSE_CODE){//Add course || view course
                loadDataInCourseListView();
            } else {
                Intent show = new Intent(getApplicationContext(), ListTerms.class);
                setResult(Activity.RESULT_OK, show);
                finish();
            }
        }
    }
}