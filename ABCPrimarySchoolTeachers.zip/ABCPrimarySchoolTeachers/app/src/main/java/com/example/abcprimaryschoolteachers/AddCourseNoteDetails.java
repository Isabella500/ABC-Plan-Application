package com.example.abcprimaryschoolteachers;

import android.content.ContentValues;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.abcprimaryschoolteachers.database.DBHelper;
import com.example.abcprimaryschoolteachers.database.DBManager;

public class AddCourseNoteDetails extends AppCompatActivity {

    Button btnCancel,btnSave;

    EditText edTitle,edNote;
    TextView txtCourseName;

    String courseId,termId,courseName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_course_note_details);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Add Note");

        courseId = getIntent().getStringExtra("course_id");
        termId = getIntent().getStringExtra("term_id");
        courseName = getIntent().getStringExtra("course_name");

        txtCourseName = (TextView) findViewById(R.id.lbl_course_name);
        edTitle = findViewById(R.id.edTitle);
        edNote = findViewById(R.id.edNote);
        btnCancel = findViewById(R.id.btnCancel);
        btnSave = findViewById(R.id.btnSave);

        txtCourseName.setText("Course : "+courseName);

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title = edTitle.getText().toString();
                String note = edNote.getText().toString();
                if(title.isEmpty()){
                    Toast.makeText(getApplicationContext(),"Enter Title",Toast.LENGTH_LONG).show();
                } else if(note.isEmpty()){
                    Toast.makeText(getApplicationContext(),"Enter Note",Toast.LENGTH_LONG).show();
                } else {
                    DBManager db = new DBManager(getApplicationContext());
                    ContentValues contentValues = new ContentValues();
                    contentValues.put(DBHelper.KEY_CNOTES_COURSE_ID, courseId);
                    contentValues.put(DBHelper.KEY_CNOTES_NOTE, note);
                    contentValues.put(DBHelper.KEY_CNOTES_TITLE, title);
                    db.insert(DBHelper.TABLE_COURSE_NOTES, contentValues);
                    Intent i = new Intent();
                    setResult(RESULT_OK, i);
                    finish();
                }
            }
        });
    }


    @Override
    public boolean onSupportNavigateUp(){
        finish();
        return true;
    }
}