package com.example.abcprimaryschoolteachers;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;


import com.example.abcprimaryschoolteachers.database.DBHelper;
import com.example.abcprimaryschoolteachers.database.DBManager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ViewReport extends AppCompatActivity {

    ListView listReportData;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_report);

        getSupportActionBar().setTitle("Courses Report");

        listReportData = findViewById(R.id.listReportData);

        Map<String,Integer> statusMap = new HashMap<>();
        List<String> listData = new ArrayList<>();
        statusMap.put("Easy",0);
        statusMap.put("Moderate",0);
        statusMap.put("Difficult",0);
        DBManager db = new DBManager(getApplicationContext());
        String qry = "select "
                + DBHelper.KEY_COURSE_WHERE +",COUNT("+DBHelper.KEY_COURSE_ID+") "
                + " FROM "
                + DBHelper.TABLE_COURSE
                +" group by "+DBHelper.KEY_COURSE_WHERE;
        Cursor c = db.fetchWithQuery(qry);
        if (c != null && c.getCount() > 0) {
            do {
                String status = c.getString(0);
                int count = c.getInt(1);
                if(statusMap.containsKey(status)){
                    statusMap.put(status,count);
                }
            } while (c.moveToNext());
        }

        for (Map.Entry<String, Integer> e: statusMap.entrySet()) {
            String key = e.getKey();
            int val = e.getValue();
            listData.add(key +" - "+val);
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listData);
        listReportData.setAdapter(adapter);

    }
}