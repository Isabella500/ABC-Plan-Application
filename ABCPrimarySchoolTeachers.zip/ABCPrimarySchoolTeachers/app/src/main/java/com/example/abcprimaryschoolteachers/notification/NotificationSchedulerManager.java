package com.example.abcprimaryschoolteachers.notification;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;

import com.example.abcprimaryschoolteachers.database.DBHelper;
import com.example.abcprimaryschoolteachers.database.DBManager;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Random;
import java.util.TimeZone;

public class NotificationSchedulerManager {
    public static Random r = new Random();
    public static int maxRange = 1000000;
    public static int setNotification(Context context, String title, String msg, long time,int dbOldAlertCode){
        if(dbOldAlertCode != 0){
            deleteAlarm(context,dbOldAlertCode);

        }
        int alertCode = r.nextInt(maxRange);
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(context, NotificationReceiver.class);
        intent.putExtra("alarmid", alertCode);
        intent.putExtra("title", title);
        intent.putExtra("msg",msg);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(context, alertCode, intent, PendingIntent.FLAG_UPDATE_CURRENT);
        am.set(AlarmManager.RTC_WAKEUP, time, pendingIntent);
        insertAlarm(context, alertCode, title, time);
        System.out.println("NEW ALERT_CODE -> " + alertCode);
        return alertCode;
    }

    private static void insertAlarm(Context context, int alertCode, String title, long time) {
        DBManager db = new DBManager(context);
        ContentValues contentValues = new ContentValues();
        contentValues.put(DBHelper.KEY_ALERT_CODE, alertCode);
        contentValues.put(DBHelper.KEY_ALERT_ALERT_TYPE, title);
        contentValues.put(DBHelper.KEY_ALERT_EVENT_AT, time);
        contentValues.put(DBHelper.KEY_ALERT_EVENT_WHERE,"PENDING");
        db.insert(DBHelper.TABLE_ALERT, contentValues);
    }

    public static void deleteAlarm(Context context, int dbAlertCode) {
        cancelAlarm(context,dbAlertCode);
        String code = String.valueOf(dbAlertCode);
        DBManager db = new DBManager(context);
        db.delete(DBHelper.TABLE_ALERT,DBHelper.KEY_ALERT_CODE+"=?",new String[]{code});
        System.out.println("DELETE ALERT_CODE -> " + dbAlertCode);
    }

    public static void cancelAlarm(Context context, int dbAlertCode) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Intent myIntent = new Intent(context, NotificationReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                context, dbAlertCode, myIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
    }


    public static  Long convertToTimestamp(String sDate) {
        long lng = 0L;
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yy", Locale.getDefault());
            Date date = dateFormat.parse(sDate + TimeZone.getDefault().getDisplayName());
            lng = date.getTime();
        }
        catch (ParseException e) {
        }
        return lng;
    }
    public static long getCurrentDateInLong(){
        long lng = 0L;
        try{
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            String date = dateFormat.format(new Date());
            Date currentDate = dateFormat.parse(date);
            lng = currentDate.getTime();
        }catch (ParseException e){
        }
        return lng;
    }
}
