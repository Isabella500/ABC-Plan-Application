package com.example.abcprimaryschoolteachers.domain;

public class Assessment {
    int id,courseId;
    String type,name,dueDate;

    public Assessment(){}

    public Assessment(int id, int courseId, String type, String name, String dueDate) {
        this.id = id;
        this.courseId = courseId;
        this.type = type;
        this.name = name;
        this.dueDate = dueDate;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCourseId() {
        return courseId;
    }

    public void setCourseId(int courseId) {
        this.courseId = courseId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDueDate() {
        return dueDate;
    }

    public void setDueDate(String dueDate) {
        this.dueDate = dueDate;
    }
}
