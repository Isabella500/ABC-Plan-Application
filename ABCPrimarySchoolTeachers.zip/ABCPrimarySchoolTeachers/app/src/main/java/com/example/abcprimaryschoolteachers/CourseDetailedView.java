package com.example.abcprimaryschoolteachers;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.abcprimaryschoolteachers.database.DBHelper;
import com.example.abcprimaryschoolteachers.database.DBManager;
import com.example.abcprimaryschoolteachers.domain.Assessment;
import com.example.abcprimaryschoolteachers.domain.Notes;
import com.example.abcprimaryschoolteachers.domain.Student;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class CourseDetailedView extends AppCompatActivity {

    TextView txttitle,txtStartDate,txtEndDate,txtwhere,txtStudent;
    String courseId,termsid, studentId;
    Button btnEditCourse,btnDeleteCourse, btnViewAllStudents;


    ListView listViewNotes;
    List<String> ListNotesElementsArrayList = new ArrayList<>();
    final List<Notes> ListNotes = new ArrayList<>();

    ListView listViewAssessment;
    List<String> ListAssessmentElementsArrayList = new ArrayList<>();
    List<Assessment> ListAssessment = new ArrayList<>();

    ListView StudentViewList;
    List<String> ListElementsArrayList = new ArrayList<>();
    final List<Student> ListStudentsElementsArrayList = new ArrayList<>();

    int EDIT_COURSE_DETAIL_CODE = 1;
    int EDIT_NOTES_CODE = 2;
    int ADD_NOTES_CODE = 3;
    int ADD_ASSESSMENT_CODE = 4;
    int EDIT_ASSESSMENT_CODE = 5;
    int LIST_STUDENTS_CODE = 6;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_detailed_view);

        getSupportActionBar().setTitle("Course Detailed View");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        txttitle = findViewById(R.id.lblCourseTitleValue);
        txtStartDate = findViewById(R.id.lblCourseStartValue);
        txtEndDate = findViewById(R.id.lblCourseEndValue);
        txtwhere = findViewById(R.id.lblWhereValue);
        btnEditCourse = findViewById(R.id.btnEditCourse);
        btnDeleteCourse = findViewById(R.id.btnDeleteCourse);
        listViewNotes = findViewById(R.id.listViewNotes);
        listViewAssessment = findViewById(R.id.listViewAssessment);
        btnViewAllStudents = findViewById(R.id.btnViewAllStudents);

        courseId = getIntent().getStringExtra("course_id");
        LoadDetailViewData();

        btnDeleteCourse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            new AlertDialog.Builder(com.example.abcprimaryschoolteachers.CourseDetailedView.this)
                .setTitle("Delete")
                .setMessage("Are you sure that you want to delete this course?")
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                        DBManager db = new DBManager(getApplication());
                        db.delete(DBHelper.TABLE_COURSE,DBHelper.KEY_COURSE_ID+"=?",new String[]{courseId});
                        db.delete(DBHelper.TABLE_COURSE_NOTES,DBHelper.KEY_CNOTES_COURSE_ID+"=?",new String[]{courseId});
                        Intent show = new Intent();
                        setResult(Activity.RESULT_OK,show);
                        finish();
                    }})
                .setNegativeButton(android.R.string.no, null).show();
            }
        });
        btnEditCourse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent show = new Intent(getApplicationContext(), EditCourseDetails.class);
                show.putExtra("course_id",courseId);
                startActivityForResult(show,EDIT_COURSE_DETAIL_CODE);
            }
        });
        btnViewAllStudents.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent show = new Intent(getApplicationContext(), StudentList.class);
                show.putExtra("student_id",studentId);
                startActivityForResult(show,LIST_STUDENTS_CODE);
            }
        });


        loadDataInNotesListView();

        //item click on detail view
        listViewNotes.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Notes n = ListNotes.get(position);
                Intent i = new Intent(getApplicationContext(), EditCourseNoteDetails.class);
                i.putExtra("note_id", String.valueOf(n.getId()));
                i.putExtra("term_id",termsid);
                String courseName = txttitle.getText().toString();
                i.putExtra("course_name",courseName);
                startActivityForResult(i,EDIT_NOTES_CODE);
            }
        });
        //Long press for delete course
        listViewNotes.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                //Toast.makeText(getApplicationContext(),position+" - "+ListMentor.size(),Toast.LENGTH_LONG).show();
                final Notes n = ListNotes.get(position);
                androidx.appcompat.app.AlertDialog.Builder alert = new androidx.appcompat.app.AlertDialog.Builder(com.example.abcprimaryschoolteachers.CourseDetailedView.this);
                alert.setTitle("Alert");
                alert.setMessage("Are you sure to delete?");
                alert.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        DBManager db = new DBManager(getApplicationContext());
                        db.delete(DBHelper.TABLE_COURSE_NOTES,DBHelper.KEY_CNOTES_ID+"=?",new String[]{""+n.getId()});
                        loadDataInNotesListView();
                        dialog.dismiss();
                    }
                });
                alert.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                alert.show();
                return true;
            }
        });

        loadDataInAssessmentListView();
        //item click on edit view
        listViewAssessment.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Assessment ass = ListAssessment.get(position);
                Intent i = new Intent(getApplicationContext(), EditAssessmentDetails.class);
                i.putExtra("assignment_id", String.valueOf(ass.getId()));
                i.putExtra("term_id",termsid);
                i.putExtra("course_name",txttitle.getText().toString());
                startActivityForResult(i,EDIT_ASSESSMENT_CODE);
            }
        });
        //item long press for delete
        listViewAssessment.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                final Assessment ass = ListAssessment.get(position);
                androidx.appcompat.app.AlertDialog.Builder alert = new androidx.appcompat.app.AlertDialog.Builder(com.example.abcprimaryschoolteachers.CourseDetailedView.this);
                alert.setTitle("Alert");
                alert.setMessage("Are you sure to delete?");
                alert.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        DBManager db = new DBManager(getApplicationContext());
                        db.delete(DBHelper.TABLE_ASSESSMENT,DBHelper.KEY_ASSESSMENT_ID+"=?",new String[]{""+ass.getId()});
                        loadDataInAssessmentListView();
                        dialog.dismiss();
                    }
                });
                alert.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                alert.show();
                return true;
            }
        });
    }

    private void loadDataInAssessmentListView() {
        ListAssessmentElementsArrayList.clear();
        ListAssessment.clear();
        DBManager db = new DBManager(getApplicationContext());
        String[] columns = new String[]{DBHelper.KEY_ASSESSMENT_ID, DBHelper.KEY_ASSESSMENT_COURSE_ID, DBHelper.KEY_ASSESSMENT_NAME,DBHelper.KEY_ASSESSMENT_TYPE};
        String whereCluse = DBHelper.KEY_ASSESSMENT_COURSE_ID + "=?";
        Cursor c = db.fetch(DBHelper.TABLE_ASSESSMENT, columns,whereCluse,new String[]{courseId},DBHelper.KEY_ASSESSMENT_NAME);
        if (c != null && c.getCount() > 0) {
            do {
                Assessment a = new Assessment();
                a.setId(c.getInt(c.getColumnIndex(DBHelper.KEY_ASSESSMENT_ID)));
                a.setName(c.getString(c.getColumnIndex(DBHelper.KEY_ASSESSMENT_NAME)));
                a.setType(c.getString(c.getColumnIndex(DBHelper.KEY_ASSESSMENT_TYPE)));
                ListAssessmentElementsArrayList.add(a.getName()+" - "+a.getType());
                ListAssessment.add(a);
            } while (c.moveToNext());
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, ListAssessmentElementsArrayList);
        listViewAssessment.setAdapter(adapter);
    }

    private void loadDataInNotesListView() {
        ListNotesElementsArrayList.clear();
        ListNotes.clear();
        DBManager db = new DBManager(getApplicationContext());
        String[] columns = new String[]{DBHelper.KEY_CNOTES_ID, DBHelper.KEY_CNOTES_COURSE_ID, DBHelper.KEY_CNOTES_TITLE};
        String whereCluse = DBHelper.KEY_CNOTES_COURSE_ID + "=?";
        Cursor c = db.fetch(DBHelper.TABLE_COURSE_NOTES, columns,whereCluse,new String[]{courseId},DBHelper.KEY_CNOTES_TITLE);
        if (c != null && c.getCount() > 0) {
            do {
                Notes m = new Notes();
                m.setId(c.getInt(c.getColumnIndex(DBHelper.KEY_CNOTES_ID)));
                m.setCourseId(c.getInt(c.getColumnIndex(DBHelper.KEY_CNOTES_COURSE_ID)));
                m.setTitle(c.getString(c.getColumnIndex(DBHelper.KEY_CNOTES_TITLE)));
                ListNotesElementsArrayList.add(m.getTitle());
                ListNotes.add(m);
            } while (c.moveToNext());
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, ListNotesElementsArrayList);
        listViewNotes.setAdapter(adapter);
    }

    private void LoadDetailViewData() {
        DBManager db = new DBManager(getApplicationContext());
        String qry = "SELECT "
                + "c." +DBHelper.KEY_COURSE_TITLE + ",c." + DBHelper.KEY_COURSE_START_DATE + ",c." + DBHelper.KEY_COURSE_END_DATE
                + ",c." + DBHelper.KEY_COURSE_WHERE + ",c." + DBHelper.KEY_COURSE_TERMS_ID + ",m." + DBHelper.KEY_STUDENT_NAME
                +" FROM "
                + DBHelper.TABLE_COURSE+" c,"+DBHelper.TABLE_STUDENT+" m "
                +" WHERE c."+DBHelper.KEY_COURSE_STUDENT_ID +" = m."+ DBHelper.KEY_STUDENT_ID+" and c."+DBHelper.KEY_COURSE_ID+" = "+courseId;
        //Toast.makeText(getApplicationContext(),qry,Toast.LENGTH_LONG).show();
        Cursor c = db.fetchWithQuery(qry);
        if (c != null && c.getCount() > 0) {
            txttitle.setText(c.getString(0));
            String startDate = c.getString(1);
            String endDate = c.getString(2);

            try{
                Date sd = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).parse(startDate);
                startDate = "START DATE : "+new SimpleDateFormat("MM/dd/YYYY",Locale.getDefault()).format(sd);
                txtStartDate.setText(startDate);
                Date ed = new SimpleDateFormat("yyyy-MM-dd",Locale.getDefault()).parse(endDate);
                endDate = "END DATE :"+new SimpleDateFormat("MM/dd/YYYY",Locale.getDefault()).format(ed);
                txtEndDate.setText(endDate);
            } catch (Exception e){
                System.out.println(e.getMessage());
            }
            txtwhere.setText("Where : "+c.getString(3));
            termsid = c.getString(4);

        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(0,0,Menu.NONE,"Add Notes");//.setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);
        menu.add(0,1,Menu.NONE,"Add Assessment");

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent show;
        switch (item.getItemId()) {
            case 0:
                show = new Intent(getApplicationContext(), AddCourseNoteDetails.class);
                show.putExtra("term_id",termsid);
                show.putExtra("course_id",courseId);
                show.putExtra("course_name",txttitle.getText().toString());
                startActivityForResult(show,ADD_NOTES_CODE);
                break;
            case 1:
                show = new Intent(getApplicationContext(), AddAssessmentDetails.class);
                show.putExtra("term_id",termsid);
                show.putExtra("course_id",courseId);
                show.putExtra("course_name",txttitle.getText().toString());
                startActivityForResult(show,ADD_ASSESSMENT_CODE);
                break;
        }
        return (super.onOptionsItemSelected(item));
    }

    @Override
    public boolean onSupportNavigateUp(){
        finish();
        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if(requestCode == ADD_NOTES_CODE || requestCode == EDIT_NOTES_CODE){
                loadDataInNotesListView();
            } else if (requestCode == EDIT_COURSE_DETAIL_CODE) {
                Intent i = new Intent();
                setResult(RESULT_OK,i);
                finish();
            } else if(requestCode == ADD_ASSESSMENT_CODE || requestCode == EDIT_ASSESSMENT_CODE){
                loadDataInAssessmentListView();
            }
        }
    }

}