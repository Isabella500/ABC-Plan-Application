package com.example.abcprimaryschoolteachers.domain;


public class Course {
    private int courseId;
    private String courseTitle;
    private String courseStartDate;
    private String courseEndDate;
    private String courseType;
    private String courseStudent;

    public Course(){}
    public Course(int courseId, String courseTitle, String courseStartDate, String courseEndDate, String courseType, String courseStudent) {
        this.courseId = courseId;
        this.courseTitle = courseTitle;
        this.courseStartDate = courseStartDate;
        this.courseEndDate = courseEndDate;
        this.courseType = courseType;
        this.courseStudent= courseStudent;
    }

    public int getCourseId() {
        return courseId;
    }

    public void setCourseId(int courseId) {
        this.courseId = courseId;
    }

    public String getCourseTitle() {
        return courseTitle;
    }

    public void setCourseTitle(String courseTitle) {
        this.courseTitle = courseTitle;
    }

    public String getCourseStartDate() {
        return courseStartDate;
    }

    public void setCourseStartDate(String courseStartDate) {
        this.courseStartDate = courseStartDate;
    }

    public String getCourseEndDate() {
        return courseEndDate;
    }

    public void setCourseEndDate(String courseEndDate) {
        this.courseEndDate = courseEndDate;
    }

    public String getCourseType() {
        return courseType;
    }

    public void setCourseType(String courseType) {
        this.courseType = courseType;
    }

    public String getCourseStudent() {
        return courseStudent;
    }

    public void setCourseStudent(String courseMentor) {
        this.courseStudent = courseMentor;
    }
}

